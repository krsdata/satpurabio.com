<?php include"header.php"; ?>
			<div class="bg-wrapper aout-page">
				<section id="title-box" class="paralax bg-opacity-color about">
					<div class="wrapper">
			 	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<h1>About us</h1>
							<span class="subtitle">Get In Touch If You Need Help or Ask Something </span>
						</div>
					</div>
				</section>
				<section id="breadcrumbs" class="tooth tooth-green">
					<div class="section-bg">
						<div class="wrapper top-bug">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<ul>
									<li>
										<a href="index.php">Home</a>
									</li>
									<li>
										<span>About us</span>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</section>
				<section class="title-center">
					<div class="wrapper">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="section-title-box title-box-center wow bounceInDown center">
								<h2>Satpura Bio Fertiliser India Pvt Ltd</h2>
								
							</div>
						</div>
						<div class="row-3-col">
							<div class="col-md-12" align="justify" style="font-weight:500;">
                            <p> 

We are very glad to inform you, with kind objective Satpura Bio Fertilizer India Pvt Ltd. has started their activities for helping Indian Farmers to maximize farm productivity.
</p>

<p>
 We are one of the master manufacturers  and suppliers of a quality array of Bio Fertilizers like Organic Soil Conditioner, Plant Growth Promoters, Fungicide,Enzyme(Seaweed Extracts) Sprader,Neem oil,Micronutrents  in India which are strictly manufactured under strict direction of professionals. As we use superior quality raw ingredients we assure our clients for the superb quality and high functionality. Our experienced team is engaged in manufacturing all products using qualitative raw material sourced from certified vendors base. SATPURA  is committed to consistently providing the best quality and cost effective  products to our customers ensuring complete customer satisfaction  through continuous up gradation of our quality management systems.
</p>
<p>We are one of the master manufacturers  and suppliers of a quality array of Bio Fertilizers like Organic Soil Conditioner, Plant Growth Promoters, Fungicide,Enzyme(Seaweed Extracts) Sprader,Neem oil,Micronutrents  in India which are strictly manufactured under strict direction of professionals. As we use superior quality raw ingredients we assure our clients for the superb quality and high functionality. Our experienced team is engaged in manufacturing all products using qualitative raw material sourced from certified vendors base. SATPURA  is committed to consistently providing the best quality and cost effective  products to our customers ensuring complete customer satisfaction  through continuous up gradation of our quality management systems .</p>
                           <!-- <p>Supported by a group of highly experienced and well-trained professionals, we have been able to operate our business operations in a highly effective manner. Our team of professionals is well-versed with top notch technology with utilizing the tools and upgraded machines installed in our infrastructure unit. All offered products are manufactured in our sophisticated manufacturing facility in tune with the industry defined quality norms. Moreover, we have recruited highly diligent quality professionals who stringently examine offered products before prior dispatch to our clients.
</p>
<p>Supported by our well qualified mentor, "Mr. Praween Rai", we have been able to gain such a rapid growth in the market. Under his valuable supervision, we have created a broad client-base owing to his great managerial skills and ability to take random decisions with optimum accuracy.</p>-->
                            </div>
						</div>
					</div>
				</section>
				
				<section class="exspertize flower-img">
					<div class="tooth-color-white"></div>
					<div class="wrapper">
                    
                    <div class="col-md-4">
                                 
                                </div>
						<div class="row row-custom col-md-4 col-lg-4 col-sm-12 col-xs-12">
							 <h3>OUR VISION</h3>
                                  <ul class="list-style-circle">
								<li>To become leading player in agri inputs segment. </li>
                                </ul><br />
								<h3>OUR VALUES</h3>
                               <ul class="list-style-circle">
							<li>Integrity in all our thoughts and actions </li>
                            <li>Equality in our dealings with customers, employees and stakeholders</li>
                            <li>Collaboration with clients, vendors and partners </li>
                            <li>We always trying to serve batter than batter to our customers.  </li>
                            </ul>
						</div>
                                  
                                
                                 <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                                 <h3>OUR MISSION </h3>
                               <ul class="list-style-circle">
							<li>To delight our consumers of products with superior quality and value.</li>
                            <li>To Inspire our people to work passionately and harmoniously</li>
                            <li>To Inspire our people to work passionately and harmoniously </li>
                            <li>To contribute to the growth of society as we grow the company's                           business. </li>
                            <li>To protect the green environment of the earth for the future generation.</li>
                            <li>To Ensure to gate cast effective and quality of craft. </li>
                            <li>To reduce consumption of chemical fertilizers in Indian forming </li>
                            </ul>
                                </div>
						<!--<div class="row row-custom expertise-box">
							
                            
                            
                           
                            
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 wow fadeInRight">
								<h3>OUR MISSION </h3>

							<p>To delight our consumers of products with superior quality and value.</p>
                            <p>To Inspire our people to work passionately and harmoniously</p>
                            <p>To Inspire our people to work passionately and harmoniously </p>
                            <p>To contribute to the growth of society as we grow the company's                           business. </p>
							</div>
						</div>-->
						<div class="row our-info-box percent-blocks">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            
								
							</div>
						</div>
					</div>
				</section>
				<section class="color-bg">
					<div class="wrapper">
						<div class="row-4">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row-2-blocks row-2-blocks-2">
									<div class="r-block-1">
										<div class="c-content-block wow fadeInDown top__element">
											<h2>Tell Us What You Are Looking For?</h2>
											<div>Friendly customer service staff for your all questions!</div>
										</div>
									</div>
									<div class="r-block-2">
											<a class="btn big-circle pull-right" href="contact.php">
											<div class="big-text">
												GET in touch today!
											</div>
											<div class="sm-text">
												We'll fix all your Problems!
											</div>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="tooth-color-gr"></div>
				</section>
				<section class="quote-olw">
					<div class="wrapper">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="section-title-box wow rollIn center">
									<h2>Happy Customers</h2>
									<span></span>
								</div>
							</div>
						</div>
						<div class="row quote-row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div id="quote-olw">
								<div class="quote-box">
									<quote class="quote-block-2">
										<div class="quote-wrap">
											
											<div class="text-quote">
												<p>Satpura Bio Fertilizers services are consistent, competitively priced, and their team is easy to work with.I really appreciate all of company's efforts. Anytime a vendor provides information before we have time to ask for it, I just love it.</p>
											</div>
										</div>
										<span class="ef arrow_triangle-down"></span>
									</quote>
									<div class="q-signature">
										<h4>Rakesh Jain</h4>
										<div class="q-sub"></div>
									</div>
								</div>
								<div class="quote-box">
									<quote class="quote-block-2">
										<div class="quote-wrap">
											
											<div class="text-quote">
												<p> I have used Humix Humic Acid for the growth of plants roots., it shows tremendous and excellent result in for crop cultivation. I should suggested the people should use this golden product. It is perfect product for agriculture field and I also thanks the Satpura Bio Fertilizers for there best products.</p>

											</div>
										</div>
										<span class="ef arrow_triangle-down"></span>
									</quote>
									<div class="q-signature">
										<h4>Mayur Sharma</h4>
										<div class="q-sub"></div>
									</div>
								</div>
								<div class="quote-box">
									<quote class="quote-block-2">
										<div class="quote-wrap">
											
											<div class="text-quote">
												<p>I have applied Bhumi Rakshak in my flower crop with in 20 days i got very excellent result .i have getting regular good yield It is wonderful I have got best results. Thanks to Satpura Bio Fertilizers pvt ltd.</p>

											</div>
										</div>
										<span class="ef arrow_triangle-down"></span>
									</quote>
									<div class="q-signature">
										<h4>Rayasil Zadu</h4>
										<div class="q-sub"></div>
									</div>
								</div>
								<!--<div class="quote-box">
									<quote class="quote-block-2">
										<div class="quote-wrap">
											<div class="quote-photo">
												<img class="#" alt="image" src="media/76x76/image1.jpg">
											</div>
											<div class="text-quote">
												<p>Nulla euismod malesuada nibh. Donec nunc. Praesent sit amet turpis eu nisl faucibus pharetra. Fusce quis neque vel leo semp er rhoncus. Ut interdum, risus id luctus consectetuer velit neq ue ornare quam beat ornare nisi velit nec turpis. Mauris lorem. Phasellus egestas urna vel sem. Ut auctor.</p>
											</div>
										</div>
										<span class="ef arrow_triangle-down"></span>
									</quote>
									<div class="q-signature">
										<h4>Jeebon Heza</h4>
										<div class="q-sub">Home Owner, Newyork</div>
									</div>
								</div>
								<div class="quote-box">
									<quote class="quote-block-2">
										<div class="quote-wrap">
											<div class="quote-photo">
												<img class="#" alt="image" src="media/76x76/image2.jpg">
											</div>
											<div class="text-quote">
												<p>Nulla euismod malesuada nibh. Donec nunc. Praesent sit amet turpis eu nisl faucibus pharetra. Fusce quis neque vel leo semp er rhoncus. Ut interdum, risus id luctus consectetuer velit neq ue ornare quam beat ornare nisi velit nec turpis. Mauris lorem. Phasellus egestas urna vel sem. Ut auctor.</p>
											</div>
										</div>
										<span class="ef arrow_triangle-down"></span>
									</quote>
									<div class="q-signature">
										<h4>Rayasil Zadu</h4>
										<div class="q-sub">Home Owner, California</div>
									</div>
								</div>
								<div class="quote-box">
									<quote class="quote-block-2">
										<div class="quote-wrap">
											<div class="quote-photo">
												<img class="#" alt="image" src="media/76x76/image1.jpg">
											</div>
											<div class="text-quote">
												<p>Nulla euismod malesuada nibh. Donec nunc. Praesent sit amet turpis eu nisl faucibus pharetra. Fusce quis neque vel leo semp er rhoncus. Ut interdum, risus id luctus consectetuer velit neq ue ornare quam beat ornare nisi velit nec turpis. Mauris lorem. Phasellus egestas urna vel sem. Ut auctor.</p>
											</div>
										</div>
										<span class="ef arrow_triangle-down"></span>
									</quote>
									<div class="q-signature">
										<h4>Jeebon Heza</h4>
										<div class="q-sub">Home Owner, Newyork</div>
									</div>
								</div>-->
							</div>
							
						</div>
					</div>
				</section>
			</div>
			<?php include"footer.php"; ?>