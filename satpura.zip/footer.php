    
            
              <footer id="footer">
				<div class="footer-blocks">
					<div class="wrapper">
						<div class="row-footer">
							<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 wow fadeInLeft">
								<div class="footer-logo">
									<a href="index.php" class="logo-footer"></a>
								</div>
								<div class="f-b-box justify">
									<span class="contact-info">We are one of the master manufacturers and suppliers of a quality array of Bio Fertilizers like Organic Soil Conditioner, Plant Growth Promoters, Fungicide, Enzyme(Seaweed Extracts) Sprader, Neem oil, Micronutrents in India</span> <br /> <br />
									<a class="btn btn-border dark" href="about.php"><span>Read More</span></a>
									
								</div>

								<form action="http://templines.us9.list-manage.com/subscribe/post?u=fe9a9cfcf8d73763bcc53f206&amp;id=319cafcc43" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
												<div id="mc_embed_signup_scroll">
													<div class="mc-field-group">
														<input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL" placeholder="Enter your email">
													</div>
													<div id="mce-responses" class="clear">
														<div class="response" id="mce-error-response" style="display:none"></div>
														<div class="response" id="mce-success-response" style="display:none"></div>
													</div>
													<!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
													<div style="position: absolute; left: -5000px;">
														<input type="text" name="b_fe9a9cfcf8d73763bcc53f206_319cafcc43" tabindex="-1" value="#">
													</div>
													<div class="clear">
														<button type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe"   class="btn btn-primary btn-icon-right"><span class="btn-icon"><i class="fa-2x fa fa-envelope  "></i></span> </button>
													</div>
												</div>
											</form>
							</div>
							<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 wow fadeInUp">
								<h4 class="border">Latest Tweets</h4>
								<div class="f-b-box">
									<ul class="lat-tw">
										<li>
											<span class="ef social_twitter_circle"></span>
											<div class="tw-message">
												Cras augues ipsum mpharetra inter integ anterl nuno <a href=".html">http://t.co/JGwd</a>
											</div>
											<div class="tw-time">1 minute ago</div>
										</li>
										<li>
											<span class="ef social_twitter_circle"></span>
											<div class="tw-message">
												Cras augues ipsum mpharetra inter integ anterl nuno <a href=".html">http://t.co/JGwd</a>
											</div>
											<div class="tw-time">35 minute ago</div>
										</li>
										
									</ul>
								</div>
							</div>
							<!--<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 wow fadeInUp">
								<h4 class="border">Instagram Feed</h4>
								<div class="f-b-box">
									<div class="i-row">
										<div class="box-i-image">
											<a href="#" class="i-image">
												<img src="media/80x80/in1.jpg" alt="instagramm"/>
											</a>
										</div>
										<div class="box-i-image">
											<a href="#" class="i-image">
												<img src="media/80x80/in2.jpg" alt="instagramm"/>
											</a>
										</div>
										<div class="box-i-image">
											<a href="#" class="i-image">
												<img src="media/80x80/in3.jpg" alt="instagramm"/>
											</a>
										</div>
									</div>
									<div class="i-row">
										<div class="box-i-image">
											<a href="#" class="i-image">
												<img src="media/80x80/in4.jpg" alt="instagramm"/>
											</a>
										</div>
										<div class="box-i-image">
											<a href=".html" class="i-image">
												<img src="media/80x80/in5.jpg" alt="instagramm"/>
											</a>
										</div>
										<div class="box-i-image">
											<a href="#" class="i-image">
												<img src="media/80x80/in6.jpg" alt="instagramm"/>
											</a>
										</div>
									</div>
									<div class="i-row">
										<div class="box-i-image">
											<a href=".html" class="i-image">
												<img src="media/80x80/in7.jpg" alt="instagramm"/>
											</a>
										</div>
										<div class="box-i-image">
											<a href=".html" class="i-image">
												<img src="media/80x80/in8.jpg" alt="instagramm"/>
											</a>
										</div>
										<div class="box-i-image">
											<a href=".html" class="i-image">
												<img src="media/80x80/in9.jpg" alt="instagramm"/>
											</a>
										</div>
									</div>
								</div>
							</div>-->
							<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 wow fadeInRight">
								<h4 class="border">Contact Info</h4>
								<div class="f-b-box">
									<div class="contact-f-wrapper">
										<div class="f-contact-box">
											<span class="contact-name">
												Address:
											</span>
											<span class="contact-info">
												<strong>Manufacturing Unit : </strong> 15 S.R.Compound Lasudia Mori,
Dewas Naka. Indore. <br />
                                                 <strong>Marketing Office : </strong> A5 Agrawal Market, Lasudia Mori,
Dewas Naka Indore 452013


											</span>
										</div>
										<div class="f-contact-box">
											<span class="contact-name">
												Phone
											</span>
											<span class="contact-info">
												0731-4700930 ,+91-9630606020, <br /> +91-9009241883  
											</span>
										</div>
										
										<div class="f-contact-box">
											<span class="contact-name">
												Email:
											</span>
											<span class="contact-info">
												info@satpurabio.com
											</span>
										</div>
									</div>

									<a class="btn btn-border dark" href="contact.php"><span>Send Message</span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="footer-bottom">
					<div class="wrapper">
						<div class="row-footer">
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 wow fadeInLeft">
								<div class="copiright">
									Copyrights Satpura Bio Fertilizer &nbsp; &bull; &nbsp;Designed By <a href="https://pitechnologies.org/"> PiTechnologies </a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 nav-footer wow fadeInRight">
								<ul>
									<li class="active">
										<a href="index.php">home</a>
									</li>
									<li>
										<a href="about.php">about</a>
									</li>
									<li>
										<a href="plant_nutrition.php">Products</a>
									</li>
                                    <li>
										<a href="vendor.php">Dealership</a>
									</li>
									<li>
										<a href="career.php">Careers</a>
									</li>
									<li>
										<a href="contact.php">contact us</a>
									</li>
									
								</ul>
							</div>
						</div>
					</div>
				</div>
			</footer>    
		</div>
        
        <a id="back-to-top" href="#" class="btn btn-default btn-lg back-to-top" role="button" title="Click to return on the top page" data-toggle="tooltip" data-placement="left"><span class="fa fa-arrow-up icon-color1"></span></a>

		<script src="plugins/switcher/js/bootstrap-select.js"></script> 
		<script src="plugins/switcher/js/evol.colorpicker.min.js" type="text/javascript"></script> 
		<script src="plugins/switcher/js/dmss.js"></script>
		
		<script src="js/jquery-ui.min.js"></script>
		<script src="js/modernizr.custom.js"></script>
		<script src="js/smoothscroll.min.js"></script>
		<script src="js/wow.min.js"></script>

		 

		<!--Owl Carousel-->
		<script src="plugins/owl-carousel/owl.carousel.min.js"></script>
		<script src="plugins/ekko-lightbox/ekko-lightbox.min.js"></script>
		<script src="js/waypoints.min.js"></script>
		<script src="js/jquery.easypiechart.min.js"></script>
		<script src="js/func.js"></script>
	</body>


</html>
