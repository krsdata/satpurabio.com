	<?php include"header.php"; ?>
            
			<div class="bg-wrapper">
				<section id="title-box" class="paralax bg-opacity-color shop">
					<div class="wrapper">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<h1>Our Products</h1>
							<span class="subtitle">The Home Of best Products</span>
						</div>
					</div>
				</section>
				<section id="breadcrumbs" class="tooth tooth-green">
					<div class="section-bg">
						<div class="wrapper">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<ul>
									<li>
										<a href="index.php">Home</a>
									</li>
									<li>
										Products
									</li>
									
								</ul>
							</div>
						</div>
					</div>
				</section>
				<section class="two-columns">
					<div class="wrapper">
						<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 pull-right">

							

							<div class="shop-grid grid-list">
								<div class="row wow fadeInUp">
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="zyme">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
												<a class="product-image-light-box" href="img/zyme-l.jpg" data-toggle="lightbox" data-title="Royal Zyme">
													<img src="img/zyme-l.jpg" alt="product"/>
												</a>
                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block">
  <h4 class="ttl">  Royal Zyme</h4>
											<h4>Dose:  8 to 12 kg per acre </h4></div><br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Royal zymes Granules increases crop yield and quality produce.</li>
													<li>Royal zymes granules can mixed with any fertilizers and insect.</li>
													<li>Royal zymes granules is non toxic and safe for users.</li>
                                                    <li>Royal zymes granules increases resistant power of plant and fight a</li>
                                                    <li>Impact of weather and disease.</li>
                                                    
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 10 kg, 20 kg, 50 kg
                                      </div>
                                      <br />
                                      
                                   
                                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                    
                                        
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
                                                
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									
                                    
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="humi">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
												<a class="product-image-light-box" href="img/humi-l.jpg" data-toggle="lightbox" data-title="Grand Humi">
													<img src="img/humi-l.jpg" alt="product"/>
												</a>
                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block">
  <h4 class="ttl">Grand Humi</h4>
											<h4>Dose:  4kg to 8 kg Acre </h4></div>
                                    <br>
                                     <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Increases vitamin content of plant. </li>
													<li>Increases availability of phosphorous.</li>
													<li>Increases germination & viability of seed.</li>
                                                    <li>Increases root respiration & formation.</li>
                                                     <li>Stimulates plant enzymes</li>
                                                      <li>It help in photosynthesis.</li>
                                                     
													
												</ul>    
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 5 kg, 10 kg, 50 kg 
                                      </div>
                                      <br />
                                      
                                     
                                     <div class="col-md-12">  
                                        <div class="col-md-8">        
                                    
                                     
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>

										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                    
                                    
									
							
								<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="neem">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
												<a class="product-image-light-box" href="img/neem-l.jpg" data-toggle="lightbox" data-title="NeemX">
													<img src="img/neem-l.jpg" alt="product"/>
												</a>
                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block">
  <h4 class="ttl"> NeemX</h4>
											<h4>Dose:  Agronomical Crop: 30-40 kg Acre,
Vegetable: 40-50 kg Acre,
Horticultural: 40-60 kg </h4></div><br>
<h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Neemx is an excellent soil conditioner & improves the soil organic content.</li>
													<li>Neemx Acts as a soil enricher.</li>
                                                    <li>Neemx help to increase the yield of plant in the long run.</li>
                                                     <li>Neemx Reduces the growth of soil pest & becteries </li>
                                                      <li>Neemx is earthworm friendly.</li>
                                                       <li>Neemx is a good source of nutrition. </li>
                                                   
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 20 kg
                                      </div>
                                      <br />
                                      
                                   
                                                
                                    <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>

								
									
                                        
									
                                        
                                        
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="swarn">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/swarn.jpg" data-toggle="lightbox" data-title="Swarn Zyme">
													<img src="img/swarn.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4 class="ttl"> Swarn Zyme </h4>
  
											<h4>Dose:  8 to 12 kg per acre </h4></div>
                                            <br>
                                            <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Swarn zymes Granules increases crop yield and quality produce.</li>
													<li>Swarn zymes granules can mixed with any fertilizers and insect.</li>
													<li>Swarn zymes granules is non toxic and safe for users.</li>
                                                    <li>Swarn zymes granules increases resistant power of plant and fight a</li>
                                                    <li>Impact of weather and disease.</li>
                                                    
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 10 kg, 20 kg, 50 kg
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                    
                                       
                                       
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                    
                                    
                                    
                                    
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
								</div>
							</div>

							<!--<div class="pagination-box">
								<ul>
									<li class="arrow-pagin">
									<a href="#">
									<span class="ef arrow_left"></span>
									</a>
									</li>
									<li class="active">
										<span class="number-pag">1</span>
									</li>
									<li>
										<a href="#">
											<span class="number-pag">2</span>
										</a>
									</li>
									<li>
										<a href="#">
											<span class="number-pag">3</span>
										</a>
									</li>
									<li class="arrow-pagin">
										<a href="#">
											<span class="ef arrow_right"></span>
										</a>
									</li>
								</ul>
							</div>-->

						</div>

						<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
							<div class="left-block-wrapper wow fadeInLeft">
								<div class="title-left-block">
									<h3 class="text-uppercase">Soil Nutrition</h3>
								</div>
								 <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" id="myScrollspy">
                                 	
            <ul class="nav nav-tabs nav-stacked" data-offset-top="190" >
                
                
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#zyme">Royal Zyme</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#humi">Grand Humi</a></span></li>
                
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#neem">NeemX</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#swarn">Swarn Zyme</a></span></li>
                
            </ul>
							</div>

					

							
							
						</div>
					</div>
				</section>
				
                <div class="modal animated slideInUp" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
          
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" style="float:right">
                    <i class="fa fa-times-circle-o"></i></button>
                <h4 class="modal-title" id="myModalLabel">
                    Enquiry Form -</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Nav tabs -->
                       
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="Login">
                            <p>If you would like to inquire about a product please fill out the form below.
                                <form class="form-horizontal">
    <div class="form-group">
      <label class="control-label col-sm-2" for="Name">Name:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Name">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="Email">Email Id:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="Phone">Phone No.:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Phone #">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="name">Message:</label>
      <div class="col-sm-10">
      	<textarea id="comment" rows="4" cols="30" name="message"></textarea>								
      </div>
    </div>
    <br>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
       <button class="button-border text-uppercase">
													<span class="text-btn">Submit</span>
													<span class="borfer-btn"></span>
												</button>
                                               <p> We will share the Details with you soon.</p>
      </div>
    </div>
  </form>
                            </div>
                           
                        </div>
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
					<?php include"footer.php"; ?>