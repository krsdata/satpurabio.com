	<?php include"header.php"; ?>
            
			<div class="bg-wrapper">
				<section id="title-box" class="paralax bg-opacity-color shop">
					<div class="wrapper">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<h1>Our Products</h1>
							<span class="subtitle">The Home Of best Products</span>
						</div>
					</div>
				</section>
				<section id="breadcrumbs" class="tooth tooth-green">
					<div class="section-bg">
						<div class="wrapper">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<ul>
									<li>
										<a href="index.php">Home</a>
									</li>
									<li>
										Products
									</li>
									
								</ul>
							</div>
						</div>
					</div>
				</section>
				<section class="two-columns">
					<div class="wrapper">
						<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 pull-right">

							

							<div class="shop-grid grid-list">
								<div class="row wow fadeInUp">
                                
                                
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="bactive">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/active1.jpg" data-toggle="lightbox" data-title="Bio Active">
													<img src="img/active1.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4 class="ttl">Bio Active</h4>
  <h5 align="center"> Humic acid + Amino Acid +Seaweed Extract </h5>
											<h4>Dose: 3 to 4 bag per acre</h4></div>
                                            <br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Improves soil structure

</li>
                                                    <li>It helps incresases the trans-location of nutrients and controls the biotic and abiotic stress conditions.
</li>
                                                    <li>Reduces the bulk density of the soil and which in turn increase the number of fibrous roots.

</li>
                                                    <li>It increases the water holding capacity of the soil.

</li>
                                                    <li>It increases the fertility of the soil.
</li>
													
                                                  
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 50 kg.

                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">Keep in a cool place.</h5>
                                       
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="rakshak">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
												<a class="product-image-light-box" href="img/rak-l.jpg" data-toggle="lightbox" data-title="Bhumi Rakshak">
													<img src="img/rak-l.jpg" alt="product"/>
                                                 
												</a>
                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block">
  <h4 class="ttl"> Bhumi Rakshak</h4>
  <h5 align="center"> Nutrient Silica Soil Conditioner </h5>
  <h5> <strong> Composition: </strong> 70% silica</h5>
											<h4>Dose: 100 kg to 120 kg per Acre</h4> </div><br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>It increases plant growth flowering &fruiting.</li>
													<li>It is rich Source of plant available silica.</li>
													<li>It has high water holding capacity.</li>
													<li>It increase crop yield & quality of crop.</li>
                                                    <li>It helps in balancing the Ph of the soil</li>
                                                    <li>It is non-toxic & Eco-Friendly</li>
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 40 kg
                                      </div>
                                      <br />
                                      
                                       
                                        
                                      <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn"> Enqiry <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>

										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									
                                    
									
                                    
                                    
									
							
								

								
									
                                        
									
                                        
                                        
									
                                    
                                    
                                    
                                    
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
								</div>
							</div>

							<!--<div class="pagination-box">
								<ul>
									<li class="arrow-pagin">
									<a href="#">
									<span class="ef arrow_left"></span>
									</a>
									</li>
									<li class="active">
										<span class="number-pag">1</span>
									</li>
									<li>
										<a href="#">
											<span class="number-pag">2</span>
										</a>
									</li>
									<li>
										<a href="#">
											<span class="number-pag">3</span>
										</a>
									</li>
									<li class="arrow-pagin">
										<a href="#">
											<span class="ef arrow_right"></span>
										</a>
									</li>
								</ul>
							</div>-->

						</div>

						<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
							<div class="left-block-wrapper wow fadeInLeft">
								<div class="title-left-block">
									<h3 class="text-uppercase">Soil Conditioners</h3>
								</div>
								 <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" id="myScrollspy">
                                 	
            <ul class="nav nav-tabs nav-stacked" data-offset-top="190" >
            
            <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#active">Bio Active</a></span></li>
            
                
                 <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#rakshak">Bhumi Rakshak</a></span></li>
                
                
                
                
                
                
                
                
                
                
                
            </ul>
							</div>

					

							
							
						</div>
					</div>
				</section>
				
                <div class="modal animated slideInUp" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
          
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" style="float:right">
                    <i class="fa fa-times-circle-o"></i></button>
                <h4 class="modal-title" id="myModalLabel">
                    Enquiry Form -</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Nav tabs -->
                       
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="Login">
                            <p>If you would like to inquire about a product please fill out the form below.
                                <form class="form-horizontal">
    <div class="form-group">
      <label class="control-label col-sm-2" for="Name">Name:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Name">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="Email">Email Id:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="Phone">Phone No.:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Phone #">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="name">Message:</label>
      <div class="col-sm-10">
      	<textarea id="comment" rows="4" cols="30" name="message"></textarea>								
      </div>
    </div>
    <br>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
       <button class="button-border text-uppercase">
													<span class="text-btn">Submit</span>
													<span class="borfer-btn"></span>
												</button>
                                               <p> We will share the Details with you soon.</p>
      </div>
    </div>
  </form>
                            </div>
                           
                        </div>
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
					<?php include"footer.php"; ?>