	<?php include"header.php"; ?>
            
			<div class="bg-wrapper">
				<section id="title-box" class="paralax bg-opacity-color shop">
					<div class="wrapper">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<h1>Our Products</h1>
							<span class="subtitle">The Home Of best Products</span>
						</div>
					</div>
				</section>
				<section id="breadcrumbs" class="tooth tooth-green">
					<div class="section-bg">
						<div class="wrapper">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<ul>
									<li>
										<a href="index.php">Home</a>
									</li>
									<li>
										Products
									</li>
									
								</ul>
							</div>
						</div>
					</div>
				</section>
				<section class="two-columns">
					<div class="wrapper">
						<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 pull-right">

							

							<div class="shop-grid grid-list">
								<div class="row wow fadeInUp">
									
									
                                    
									
                                    
                                    
									
							
								

								
									
                                        
									
                                        
                                        
									
                                    
                                    
                                    
                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="neemoil">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/neemoil.jpg" data-toggle="lightbox" data-title="XtremeNeem ">
													<img src="img/neemoil.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4 class="ttl"> XtremeNeem </h4>
											<h4>Dose: Add 2-3 ml of XtremeNeem in 1 liter of water and use</h4></div>
                                            <br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>XtremeNeem is a Natural by product of theNeem </li>
                                                    <li>It is organic and biodegradable.</li>
                                                    <li>You can use it to control insect at all stage of development. </li>
                                                    <li>It effectively control of insects. </li>
                                                    <li>XtremeNeem is a great fungicide.</li>
													<li> XtremeNeem can protect four fruit trees and berry bushes. </li>
                                                    <li> It does not pollute Water.  </li>
                                                    <li> XtremeNeem used appropriately wan't harm bees butterflies and lady lungs. Aphids ,spider mites white files .leaf hopper </li>
                                                     
                                                  
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 500 ml , 1 Lit
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">Agriculture and horticulture use only </h5>
                                        <h5>Shake well before use.</h5>
                                        <h5> Keep away from reach of children </h5>
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                        
                                        
                                        
                                        
                                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="sprite">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/sprite.jpg" data-toggle="lightbox" data-title="Sprite">
													<img src="img/sprite.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4 class="ttl"> Sprite </h4>
  <h5 align="center"> Sucking Pest, Red Spider , Leafminer  </h5>
											<h4>Dose: 15-20 ml should be properly mixed per 15 liter of water.</h4></div>
                                            <br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
												<li>Sprite is an organic protectant very effictive against Red Mite, Aphids, Jassids, Whitefly, Leafminer, Thrips and other sucking pest. </li>
                                                <li>It can be mixed with most of all pesticide, fungicide, liquid fertilizer. </li>
                                                <li>Sprite create resulting in breathing problem and ultimately killing the sucking pest. </li>	
                                                <li> Sprite is totally safe, Nontoxic & eco-friendly. 
                                                  </li>
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 450 ml , 500 ml, 1 Lit
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">For Agriculture use only </h5>
                                        <h5>Keep in cool, dry place and away from heat.</h5>
                                       
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                        
                                        
                                        
                                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="craft">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/craft.jpg" data-toggle="lightbox" data-title="Cure Craft">
													<img src="img/craft.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4 class="ttl"> Cure Craft </h4>
											<h4>Dose: 15 ml per pump</h4>
                                            <p><strong> Fun Star:</strong> A unique natural anti fungal controls the decease created from soil and seeds.</p></div>
                                            <br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Increases germination</li>
                                                    <li>Increases health of plants</li>
                                                    <li>Improves resistance power of plant </li>
                                                    <li>Reducing the deceases of plants</li>
                                                    
                                                     
                                                  
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 250 ml, 500 ml , 1 Lit
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">For agriculture use only </h5>
                                       <h5>Keep in cool, dry place and away from heat.</h5>
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                        
                                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="dhishoom">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/dhishoom.jpg" data-toggle="lightbox" data-title="Dishoom">
													<img src="img/dhishoom.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4 class="ttl"> Dishoom </h4>
											<h4>Dose: 150-120 ml per Acre</h4>
                                            </div>
                                            <br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Dishoom is a very good organic insectcide based on organic technology.</li>
                                                    <li>Dishoom works as a contact and stomach action insecticede</li>
                                                    <li>Dishoom can be most useful in all crops for control of all kind of Bollworm </li>
                                                    <li>Dishoom application can stop feeding of bollworm within two or hours or later on completely die.</li>
                                                    <li> Dishoom can be useful in all crops like cotton chilly groundnut, vegetable etc.</li>
                                                    <li> Dishoom is very safe crop and cost effective insecticede </li>
                                                    
                                                     
                                                  
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 100 ml, 250 ml, 500 ml , 1 Lit
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">For agriculture use only </h5>
                                      
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>  
                                        
                                        
								</div>
							</div>

							<!--<div class="pagination-box">
								<ul>
									<li class="arrow-pagin">
									<a href="#">
									<span class="ef arrow_left"></span>
									</a>
									</li>
									<li class="active">
										<span class="number-pag">1</span>
									</li>
									<li>
										<a href="#">
											<span class="number-pag">2</span>
										</a>
									</li>
									<li>
										<a href="#">
											<span class="number-pag">3</span>
										</a>
									</li>
									<li class="arrow-pagin">
										<a href="#">
											<span class="ef arrow_right"></span>
										</a>
									</li>
								</ul>
							</div>-->

						</div>

						<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
							<div class="left-block-wrapper wow fadeInLeft">
								<div class="title-left-block">
									<h3 class="text-uppercase">Plant Protection</h3>
								</div>
								 <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" id="myScrollspy">
                                 	
            <ul class="nav nav-tabs nav-stacked" data-offset-top="190" >
            
            <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#neemoil">XtremeNeem</a></span></li>
            
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#sprite">Sprite</a></span></li>
                  <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#craft">Cure Craft</a></span></li> 
                   <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#dhishoom">Dishoom</a></span></li>
                   
                      
            </ul>
							</div>

					

							
							
						</div>
					</div>
				</section>
				
                <div class="modal animated slideInUp" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
          
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" style="float:right">
                    <i class="fa fa-times-circle-o"></i></button>
                <h4 class="modal-title" id="myModalLabel">
                    Enquiry Form -</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Nav tabs -->
                       
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="Login">
                            <p>If you would like to inquire about a product please fill out the form below.
                                <form class="form-horizontal">
    <div class="form-group">
      <label class="control-label col-sm-2" for="Name">Name:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Name">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="Email">Email Id:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="Phone">Phone No.:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Phone #">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="name">Message:</label>
      <div class="col-sm-10">
      	<textarea id="comment" rows="4" cols="30" name="message"></textarea>								
      </div>
    </div>
    <br>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
       <button class="button-border text-uppercase">
													<span class="text-btn">Submit</span>
													<span class="borfer-btn"></span>
												</button>
                                               <p> We will share the Details with you soon.</p>
      </div>
    </div>
  </form>
                            </div>
                           
                        </div>
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
					<?php include"footer.php"; ?>