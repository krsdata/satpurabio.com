	<?php include"header.php"; ?>
            
			<div class="bg-wrapper">
				<section id="title-box" class="paralax bg-opacity-color shop">
					<div class="wrapper">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<h1>Our Products</h1>
							<span class="subtitle">The Home Of best Products</span>
						</div>
					</div>
				</section>
				<section id="breadcrumbs" class="tooth tooth-green">
					<div class="section-bg">
						<div class="wrapper">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<ul>
									<li>
										<a href="index.php">Home</a>
									</li>
									<li>
										Products
									</li>
									
								</ul>
							</div>
						</div>
					</div>
				</section>
				<section class="two-columns">
					<div class="wrapper">
						<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 pull-right">

							

							<div class="shop-grid grid-list">
								<div class="row wow fadeInUp">
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="rakshak">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
												<a class="product-image-light-box" href="img/rak-l.jpg" data-toggle="lightbox" data-title="Bhumi Rakshak">
													<img src="img/rak-l.jpg" alt="product"/>
                                                 
												</a>
                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block">
  <h4>Product Name:-  Bhumi Rakshak</h4>
											<h4>Dose: 100 kg to 120 kg Acre</h4> </div><br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>It increases plant growth flowering &fruiting.</li>
													<li>It is rich Source of plant available silica.</li>
													<li>It has high water holding capacity.</li>
													<li>It increase crop yield & quality of crop.</li>
                                                    <li>It helps in balancing the Ph of the soil</li>
                                                    <li>It is non-toxic & Eco-Friendly</li>
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 40 kg
                                      </div>
                                      <br />
                                      
                                       
                                        
                                      <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn"> Enqiry <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>

										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									
                                    
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="humi">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
												<a class="product-image-light-box" href="img/humi-l.jpg" data-toggle="lightbox" data-title="Grand Humi">
													<img src="img/humi-l.jpg" alt="product"/>
												</a>
                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block">
  <h4>Product Name:-  Grand Humi</h4>
											<h4>Dose:  4kg to 8 kg Acre </h4></div>
                                    <br>
                                     <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Increases vitamin content of plant. </li>
													<li>Increases availability of phosphorous.</li>
													<li>Increases germination & viability of seed.</li>
                                                    <li>Increases root respiration & formation.</li>
                                                     <li>Stimulates plant enzymes</li>
                                                      <li>It help in photosynthesis.</li>
                                                     
													
												</ul>    
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 5 kg, 10 kg, 50 kg 
                                      </div>
                                      <br />
                                      
                                     
                                     <div class="col-md-12">  
                                        <div class="col-md-8">        
                                    
                                     
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>

										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                    
                                    
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="zyme">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
												<a class="product-image-light-box" href="img/zyme-l.jpg" data-toggle="lightbox" data-title="Royal Zyme">
													<img src="img/zyme-l.jpg" alt="product"/>
												</a>
                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block">
  <h4>Product Name:-  Royal Zyme</h4>
											<h4>Dose:  8 to 12 kg per acre </h4></div><br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Royal zymes Granules increases crop yield and quality produce.</li>
													<li>Royal zymes granules can mixed with any fertilizers and insect.</li>
													<li>Royal zymes granules is non toxic and safe for users.</li>
                                                    <li>Royal zymes granules increases resistant power of plant and fight a</li>
                                                    <li>Impact of weather and disease.</li>
                                                    
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 10 kg, 20 kg, 50 kg
                                      </div>
                                      <br />
                                      
                                   
                                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                    
                                        
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
                                                
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
							
								<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="neem">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
												<a class="product-image-light-box" href="img/neem-l.jpg" data-toggle="lightbox" data-title="NeemX">
													<img src="img/neem-l.jpg" alt="product"/>
												</a>
                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block">
  <h4>Product Name:-  NeemX</h4>
											<h4>Dose:  Agronomical Crop: 30-40 kg Acre,
Vegetable: 40-50 kg Acre,
Horticultural: 40-60 kg </h4></div><br>
<h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Neemx is an excellent soil conditioner & improves the soil organic content.</li>
													<li>Neemx Acts as a soil enricher.</li>
                                                    <li>Neemx help to increase the yield of plant in the long run.</li>
                                                     <li>Neemx Reduces the growth of soil pest & becteries </li>
                                                      <li>Neemx is earthworm friendly.</li>
                                                       <li>Neemx is a good source of nutrition. </li>
                                                   
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 20 kg
                                      </div>
                                      <br />
                                      
                                   
                                                
                                    <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>

								
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="humix">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
												<a class="product-image-light-box" href="img/humix.jpg" data-toggle="lightbox" data-title="Humix Humic Acid">
													<img src="img/humix.jpg" alt="product"/>
												</a>
                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4>Product Name:-  Humix Humic Acid</h4>
											<h4>Dose: 100 to 150 ml per acre </h4></div>
                                        <br>
                                        <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Stimulate seed germination and helpful for the proper and healthy growth of plants roots.
</li>
                                                    <li>It help the plants to increase the up take of minerals</li>
                                                    <li>Nutrients and micro nutrient available in soil.</li>
                                                    <li>It also help the plant to be healthy in adverse climatic condition even in drought.</li>
                                                    <li>It help in maintain the fertility of soil thus increases the productivity of soil.</li>
                                                   
													
												</ul>
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 250 ml, 500 ml, 1 lit, 5 lit
                                      </div>
                                      <br />
                                      
                                   
                                                
                                    <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">Keep in a cool place.</h5>
                                        <h5>Shake well before use.</h5>
                                        <h5>Non-toxic and easy to use.</h5>
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                        
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="amaze">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
												<a class="product-image-light-box" href="img/amaze.jpg" data-toggle="lightbox" data-title="Amaze">
													<img src="img/amaze.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block">
  <h4>Product Name:-  Amaze</h4>
											<h4>Dose:  100 ml to 120 ml per acre</h4></div>
                                        <br>
                                        <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Fulfills the rebutment of proteins to the plant and helps in the rapid nourished growth of the plant.</li>
                                                    <li>Helps in increasing crop resistance</li>
                                                    <li>Improves quality of the flower and fruits.</li>
                                                    <li>Increases the rate of photosynthesis.</li>
                                                    <li>Increases the nutrients up take through roots.</li>
                                                 
													
												</ul>
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 10 ml,100 ml, 250 ml, 500 ml, 1 lit.
                                      </div>
                                      <br />
                                      
                                   
                                   <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">Keep in a cool place.</h5>
                                        <h5>Shake well before use.</h5>
                                        <h5>Non-toxic and easy to use.</h5>
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                        
                                        
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="classic">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/classic.jpg" data-toggle="lightbox" data-title="Classic">
													<img src="img/classic.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block">
  <h4>Product Name:-  Classic</h4>
											<h4>Dose: 50 ml to 75 ml per acre</h4></div>
                                        <br>
                                         <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>It has an excellent wetting property. </li>
                                                    <li>Helps in uniform distribution. </li>
                                                    <li>Increase penetration.  </li>
                                                    <li>Helps in quick drying.  </li>
                                                    <li>Enhances sticking power. </li>
													
                                                  
													
												</ul>
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 250 ml, 500 ml, 1 lit.
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">Keep in a cool place.</h5>
                                        <h5>Shake well before use.</h5>
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                    
                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="brown">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/brown.jpg" data-toggle="lightbox" data-title="Classic">
													<img src="img/brown.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4>Product Name:-  Black Brown</h4>
											<h4>Dose:  75 to 100 ml per Acre</h4></div>
                                            <br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Improve quality of the flower&fruits </li>
                                                    <li>Strengthens plant roots.</li>
                                                    <li>Helps in increasing crop resistance. </li>
                                                    <li>It increases productivity and shelf life of produce </li>
                                                    <li>Stimulate beneficial microbial activity in soil. </li>
													
                                                  
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 250ml, 500ml,1 lit
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">Keep in a cool place.</h5>
                                        <h5>Shake well before use.</h5>
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                    
                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="neemoil">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/neemoil.jpg" data-toggle="lightbox" data-title="Classic">
													<img src="img/neemoil.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4>Product Name:-  Neem Oil</h4>
											<h4>Dose: Add 2-3 ml of Ne-em oil in 1 liter of water</h4></div>
                                            <br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Neem oil is a Natural by product of theNeem </li>
                                                    <li>It is organic and biodegradable.</li>
                                                    <li>You can use it to control insect at all stage of development. </li>
                                                    <li>It effectively control of insects. </li>
                                                    <li>Neem oil is a great fungicide.</li>
													<li> Neem oil can protect four fruit trees and berry bushes. </li>
                                                    <li> It does not pollute Water.  </li>
                                                    <li> Neem oil used appropriately wan't harm bees butterflies and lady lungs. </li>
                                                  
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> ----
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">Agriculture and horticulture use are only </h5>
                                        <h5>Shake well before use.</h5>
                                        <h5> Keep away from reach of children </h5>
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                        
                                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="active">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/bioactive.jpg" data-toggle="lightbox" data-title="Bio Active">
													<img src="img/bioactive.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4>Product Name:-Bio Active</h4>
											<h4>Dose:  Take 500 gm Rio and mix with 100 kg well decomposed</h4></div>
                                            <br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Bio Active increases flowering, reduces flower dropping &import quality.

</li>
                                                    <li>Bio Active control dropping of leaves and reproductive parts like flower,fruits etc.
</li>
                                                    <li>Bio Active flowers and fruits size,shape,weight, colors,&brightness.

</li>
                                                    <li>Bio Active increases the resistant power of plant to fight against temperature,coldness, humidity, flood, drought & severe per Bio Active increases more yield.

</li>
                                                    <li>Bio Active is Non toxic and soluble in water so it can be used mixing other pesticides.

</li>
													
                                                  
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> 250 ml, 500 ml, 1 lit

                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                     <h5 style="margin-top:15px;">Keep in a cool place.</h5>
                                        <h5>Shake well before use.</h5>
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                        
                                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="micro">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/micro.jpg" data-toggle="lightbox" data-title="Micronutri">
													<img src="img/micro.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4>Product Name:- Micronutrient</h4>
											<h4>Dose: Take 500 gm amicronutri &mix with 100 kg well decomposed</h4></div>
                                            <br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Increased productivity and quality of crop. </li>
                                                    <li>Provides various macro&micro nutrients to the plant.</li>
                                                    <li>Strengthens plant roots.
</li>
                                                    <li>Increased mineral uptake.
</li>
                                                    <li>Increased shelf life of produce. 
</li>
													
                                                  
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> ----
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                    
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                        
                                        
                                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="rio">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/rio.jpg" data-toggle="lightbox" data-title="Rio-98">
													<img src="img/rio.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4>Product Name:- Rio-98</h4>
											<h4>Dose:  Take 500 gm Rio and mix with 100 kg well decomposed</h4></div>
                                            <br>
                                             <h4> Features- </h4>
												<ul class="list-style-circle border-b">
													<li>Addition of organic matter to organically deficient soil.
</li>
                                                    <li>Increases root vitality.
</li>
                                                    <li>Improved nutrient up take

</li>
                                                    <li>Increased chlorophyll synthesis.
</li>
                                                    <li>Better seed germination.
</li>
													<li>Increased fertilizer retention.
 </li>
                                                    <li>Stimulate beneficial microbial activity in soil. 
 </li>
                                                    <li>Healthier plants and improved yields
 </li>
                                                  
													
												</ul>
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> ----
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                    
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                        
                                        
                                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="av">
										<div class="product-box">
											<div class="product-image">
                                            <div class=" col-sm-12 col-xs-12">
											<a class="product-image-light-box" href="img/av.jpg" data-toggle="lightbox" data-title="AV-89">
													<img src="img/av.jpg" alt="product"/>
                                                    </a>
												                                                </div>
                                                
											</div>
											<div class="product-desc-wrapper">
								
 
  <div class="tags-block"><h4>Product Name:- AV-89</h4>
											<h4>Dose: ---- </h4></div>
                                            <br>
                                             <h4> Features- </h4>
												
                                        
                                      <div class="tags-block border-b">  
                                      <span class="bold">Packing:</span> ----
                                      </div>
                                      <br />
                                      
                                  
                                 <div class="col-md-12">  
                                        <div class="col-md-8">        
                                    
                                        </div>
                                         <div class="col-md-4"> 
                                         <br> 
    <button class="button-border text-uppercase"  data-toggle="modal" data-target="#myModal">
													<span class="text-btn">Enqiry  <i class="fa fa-comments-o"></i></span>
													
												</button>
                                                </div>
                                                </div>
										</div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
                                        
                                        
								</div>
							</div>

							<!--<div class="pagination-box">
								<ul>
									<li class="arrow-pagin">
									<a href="#">
									<span class="ef arrow_left"></span>
									</a>
									</li>
									<li class="active">
										<span class="number-pag">1</span>
									</li>
									<li>
										<a href="#">
											<span class="number-pag">2</span>
										</a>
									</li>
									<li>
										<a href="#">
											<span class="number-pag">3</span>
										</a>
									</li>
									<li class="arrow-pagin">
										<a href="#">
											<span class="ef arrow_right"></span>
										</a>
									</li>
								</ul>
							</div>-->

						</div>

						<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
							<div class="left-block-wrapper wow fadeInLeft">
								<div class="title-left-block">
									<h3 class="text-uppercase">products Categories</h3>
								</div>
								 <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" id="myScrollspy">
                                 	
            <ul class="nav nav-tabs nav-stacked" data-offset-top="190" >
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#rakshak">Bhumi Rakshak</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#humi">Grand Humi</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#zyme">Royal Zyme</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#neem">NeemX</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#humix">Humix Humic Acid</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#amaze">Amaze</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#classic">Classic</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#brown">Black Brown</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#neemoil">Neem Oil</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#active">Bio Active</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#micro">Micronutrient</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#rio">Rio-98</a></span></li>
                <li><span class="fi flaticon-plants5 clr1"></span> <span><a href="#av">AV-89</a></span></li>
            </ul>
							</div>

					

							
							
						</div>
					</div>
				</section>
				
                <div class="modal animated slideInUp" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
          
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" style="float:right">
                    <i class="fa fa-times-circle-o"></i></button>
                <h4 class="modal-title" id="myModalLabel">
                    Enquiry Form -</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Nav tabs -->
                       
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="Login">
                            <p>If you would like to inquire about a product please fill out the form below.
                                <form class="form-horizontal">
    <div class="form-group">
      <label class="control-label col-sm-2" for="Name">Name:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Name">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="Email">Email Id:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="Phone">Phone No.:</label>
      <div class="col-sm-10">
      <input type="text" class="form-control" id="name" placeholder="Enter Phone #">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="name">Message:</label>
      <div class="col-sm-10">
      	<textarea id="comment" rows="4" cols="30" name="message"></textarea>								
      </div>
    </div>
    <br>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
       <button class="button-border text-uppercase">
													<span class="text-btn">Submit</span>
													<span class="borfer-btn"></span>
												</button>
                                               <p> We will share the Details with you soon.</p>
      </div>
    </div>
  </form>
                            </div>
                           
                        </div>
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
					<?php include"footer.php"; ?>