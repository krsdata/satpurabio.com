 <?php include "header.php"; ?>

			<div id="owl-home" class="owl-carousel owl-theme home-slider">



				<div class="item">

					<div class="h-slider-bg">

						<img class="slide-bg" src="img/banner4.jpg" alt="slide-1">

					</div>

					<div class="wrapper s-custom">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-bottom:0px">

							

						</div>

					</div>

				</div>

				

				<div class="item">

					<div class="h-slider-bg">

						<img class="slide-bg" src="img/banner7.jpg" alt="slide-3">

					</div>

					<div class="wrapper s-custom-2 s-content-center">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-bottom:50px">

							<h1 class="s-border" style="top:-120px;">The Name you can Trust!</h1>

					

							<div class="input-box in-home-slider">

								
							</div>

						</div>

					</div>

				</div>
                
                
                
                <div class="item">

					<div class="h-slider-bg">

						<img class="slide-bg" src="img/b1.jpg" alt="slide-1">

					</div>

					<div class="wrapper s-custom">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-bottom:0px">

							

						</div>

					</div>

				</div>
                
                
                
                
                <div class="item">

					<div class="h-slider-bg">

						<img class="slide-bg" src="img/b2.jpg" alt="slide-1">

					</div>

					<div class="wrapper s-custom">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-bottom:0px">

							

						</div>

					</div>

				</div>
                
                



			</div><!-- <section class="tools-bg dash-top-line">

				<div class="top-icon-block"></div>

				<div class="wrapper text-center circle-box circle-box-3">

					<div class="row">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

							<div class="title-content-box hom-1 wow bounceInDown center">

								<h3>Satpura Bio Fertiliser India Pvt Ltd</h3>

								<p>We are very glad to inform you, with kind objective Satpura Bio Fertilizer India Pvt Ltd. has started their activities for helping Indian Farmers to maximize farm productivity.</p>

							</div>

						</div>



					</div>

					<div class="row hom-1-c">

						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">



							<div class="c-link-box wow rollIn">

								<a class="btn big-circle pull-right" href="vendor.php">

									<span class="c-content-block">

										<span class="ef icon_clock"></span>

										<span class="b-text">Dealer Enquiry</span>

										<span class="desc">Register Here</span>

									</span>

								</a>

							</div>



						</div>

						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">

							<div class="c-link-box wow rollIn">

								<a class="btn big-circle pull-left" href="brochure/brochure.pdf" target="_blank">

									<span class="c-content-block">

										<span class="ef icon_documents"></span>

										<span class="b-text">Download Brochure</span>

										<span class="desc">Click Here</span>

									</span>

								</a>

							</div>



						</div>

					</div>

					<div class="el-image-left hidden-xs hidden-sm"></div>

					<div class="el-image-right hidden-xs hidden-sm"></div>

				</div>

				<div class="tooth-color-w"></div>

			</section> -->





			

			<!--<section class="services right-image-box">

				<div class="wrapper">

					<div class="row-1">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

							<div class="section-title-box wow rollIn center">

								<h2>Our Services</h2>

								<span>Nam lobortis fringilla felis. Fusce vol utpate urna cras quam vitae turpis</span>

							</div>

						</div>

					</div>

					<div class="row-1 wow fadeInUp">

						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">

							<ul class="nav nav-tabs vertical-tabs">

								<li class="active">

									<a data-toggle="tab" href="#menu1">

										<img src="media/34x34/watering-can.png" alt="watering-can"/>

										<span>Garden Care</span>

									</a>

								</li>

								<li>

									<a data-toggle="tab" href="#menu2">

										<img src="media/34x34/haystack.png" alt="haystack"/>

										<span>Lawn Moving</span>

									</a>

								</li>

								<li>

									<a data-toggle="tab" href="#menu3">

										<img src="media/34x34/tractor.png" alt="tractor"/>

										<span>Rubbish Removal</span>

									</a>

								</li>

								<li>

									<a data-toggle="tab" href="#menu4">

										<img src="media/34x34/pear.png" alt="pear"/>

										<span>Landscape Design</span>

									</a>

								</li>

								<li>

									<a data-toggle="tab" href="#menu5">

										<img src="media/34x34/tap.png" alt="tap"/>

										<span>Watering Garden</span>

									</a>

								</li>

							</ul>

						</div>

						<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">

							<div class="tab-content h1-tab-content">

								<div id="menu1" class="tab-pane fade in active">

									<h3>Garden Care</h3>

									<p>Nam lobortis fringilla felis. Fusce vol utpat mi at urna. Cras ut nec quam vitae turpis sed ipsum convallis. Duis libero. Suspendisse potenti. Suspndisse ipsu porta ligula non elementum ultricies.</p>

									<p>Justo urna egestas metusl ut ornare leo augue pharetra risus. Morbid tinclunt  massa ac vestibulum rutrum.</p>

									<ul class="list-style-twig">

										<li>Careful and regular work of your garden or lawn</li>

										<li>Dignissim consectetuer neque</li>

										<li>Proin risus nibh viverra eget lobortis feugiat</li>

									</ul>

									<button class="btn extra-color text-uppercase">

										<span class="ef icon_documents"></span>

										<span>Request Free Quote</span>

									</button>

								</div>

								<div id="menu2" class="tab-pane fade">

									<h3>Lawn Moving</h3>

									<p>Nam lobortis fringilla felis. Fusce vol utpat mi at urna. Cras ut nec quam vitae turpis sed ipsum convallis. Duis libero. Suspendisse potenti. Suspndisse ipsu porta ligula non elementum ultricies.</p>

									<p>Justo urna egestas metusl ut ornare leo augue pharetra risus. Morbid tinclunt  massa ac vestibulum rutrum.</p>

									<ul class="list-style-twig">

										<li>Careful and regular work of your garden or lawn</li>

										<li>Dignissim consectetuer neque</li>

										<li>Proin risus nibh viverra eget lobortis feugiat</li>

									</ul>

									<button class="btn extra-color text-uppercase">

										<span class="ef icon_documents"></span>

										<span>Request Free Quote</span>

									</button>

								</div>

								<div id="menu3" class="tab-pane fade">

									<h3>Rubbish Removal</h3>

									<p>Nam lobortis fringilla felis. Fusce vol utpat mi at urna. Cras ut nec quam vitae turpis sed ipsum convallis. Duis libero. Suspendisse potenti. Suspndisse ipsu porta ligula non elementum ultricies.</p>

									<p>Justo urna egestas metusl ut ornare leo augue pharetra risus. Morbid tinclunt  massa ac vestibulum rutrum.</p>

									<ul class="list-style-twig">

										<li>Careful and regular work of your garden or lawn</li>

										<li>Dignissim consectetuer neque</li>

										<li>Proin risus nibh viverra eget lobortis feugiat</li>

									</ul>

									<button class="btn extra-color text-uppercase">

										<span class="ef icon_documents"></span>

										<span>Request Free Quote</span>

									</button>

								</div>

								<div id="menu4" class="tab-pane fade">

									<h3>Landscape Design</h3>

									<p>Nam lobortis fringilla felis. Fusce vol utpat mi at urna. Cras ut nec quam vitae turpis sed ipsum convallis. Duis libero. Suspendisse potenti. Suspndisse ipsu porta ligula non elementum ultricies.</p>

									<p>Justo urna egestas metusl ut ornare leo augue pharetra risus. Morbid tinclunt  massa ac vestibulum rutrum.</p>

									<ul class="list-style-twig">

										<li>Careful and regular work of your garden or lawn</li>

										<li>Dignissim consectetuer neque</li>

										<li>Proin risus nibh viverra eget lobortis feugiat</li>

									</ul>

									<button class="btn extra-color text-uppercase">

										<span class="ef icon_documents"></span>

										<span>Request Free Quote</span>

									</button>

								</div>

								<div id="menu5" class="tab-pane fade">

									<h3>Watering Garden</h3>

									<p>Nam lobortis fringilla felis. Fusce vol utpat mi at urna. Cras ut nec quam vitae turpis sed ipsum convallis. Duis libero. Suspendisse potenti. Suspndisse ipsu porta ligula non elementum ultricies.</p>

									<p>Justo urna egestas metusl ut ornare leo augue pharetra risus. Morbid tinclunt  massa ac vestibulum rutrum.</p>

									<ul class="list-style-twig">

										<li>Careful and regular work of your garden or lawn</li>

										<li>Dignissim consectetuer neque</li>

										<li>Proin risus nibh viverra eget lobortis feugiat</li>

									</ul>

									<button class="btn extra-color text-uppercase">

										<span class="ef icon_documents"></span>

										<span>Request Free Quote</span>

									</button>

								</div>

							</div>

						</div>

						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 hidden-xs hidden-sm">

							<img class="content-right-image" src="media/home/men.png" alt="men">

						</div>

					</div>

				</div>

			</section>-->



			



			<section class="why-choose-us bg-wrapper">

				<div class="wrapper" style="margin:0px; max-width:1550px; ">

					<div class="row-1 ">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

							<div class="section-title-box title-box-center custom-5 wow rollIn center">

								
								<h2>Our Products</h2>

								<span>The Name you can Trust with highly experienced and well-trained professionals!</span>
                              

							</div>

						</div>

					</div>

					<div class="row-1">

						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 hidden-xs hidden-sm im-box">

							<img class="content-left-image" alt="products" src="img/prooo.jpg">

						</div>
                        
                        <div class="col-lg-1 col-md-1 hidden-xs hidden-sm">

</div>
						<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">

							<div class="listing l-row-2">

								<ul>
                                   <li class="wow bounce">

										<span class="fl-ic flaticon-shower5"></span>

										<div class="list-content">

											<h4>Soil Conditioner</h4>

											<div><a href="soil_conditioner.php#bactive">Bio Active</a><br />
                                            <a href="soil_conditioner.php#rakshak">Bhumi Rakshak</a><br>
 </div>

										</div>

									</li>
									

									<li class="wow bounce">

										<span class="fl-ic flaticon-plants5"></span>

										<div class="list-content">

											<h4>Soil Nutrition</h4>

											<div><a href="soil_nutrition.php#zyme"> Royal Zyme</a> <br />
                                            <a href="soil_nutrition.php#humi">Grand Humi</a><br>
                                            <a href="soil_nutrition.php#neem">NeemX</a><br>
                                           <a href="soil_nutrition.php#swarn">Swarn Zyme</a><br>
</div>
                                            
                                           

										</div>

									</li>
                                    
                                    <li class="wow bounce">

										<span class="fl-ic fa fa-umbrella"></span>

										<div class="list-content">

											<h4>Plant Protection</h4>

											<div><a href="plant_protection.php#neemoil"> Extreame Neem oil</a> <br>
                                            <a href="plant_protection.php#sprite">Sprit</a><br>
                                            <a href="plant_protection.php#craft">Cure Craft</a><br>
                                            <a href="plant_protection.php#dhishoom">Dhishoom</a><br>
                                            
                                            
                                           
 <br />
                                             </div>

										</div>

									</li>

									<li class="wow bounce">

										<span class="fl-ic flaticon-sunny23"></span>

										<div class="list-content">

											<h4>Plant Nutrition</h4>

											<div><a href="plant_nutrition.php"> Bio Active</a> <br />
                                           <a href="plant_nutrition.php"> Black Brown </a><br>
                                          <a href="plant_nutrition.php">  Premier </a><br>
                                           <a href="plant_nutrition.php"> Amaze </a><br>
                                            <a href="plant_nutrition.php">Humix </a><br>
                                           <a href="plant_nutrition.php"> Rio</a><br>
                                           <a href="plant_nutrition.php"> MicroNutrient</a><br>
                                           <a href="plant_nutrition.php"> AV-89</a><br>
                                           <a href="plant_nutrition.php"> Classic</a><br>
                                            
                                            
                                            
                                            </div>

										</div>

									</li>

									

									

									

								</ul>

							</div>

						</div>

					</div>

				</div>

			</section>

			<section class="color-bg box-tools-bg home-1">

				<div class="wrapper">

					<div class="row-4">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

							<div class="row-2-blocks row-2-blocks-2 wow bounceInDown center">
<div class="col-md-4">
								<div class="r-block-2">

									<a class="btn big-circle pull-right" href="vendor.php">

										<div class="big-text">

											Trade Enquiry

										</div>

										<div class="sm-text">

											Register Here

										</div>

									</a>

								</div>
								</div>
								<div class="col-md-4">
								<div class="r-block-2">

									<a class="btn big-circle pull-right" href="brochure/brochure.pdf">

										<div class="big-text">

											Download Brochure
										</div>

										<div class="sm-text">

											Click Here

										</div>

									</a>

								</div>
								</div>
								<div class="col-md-4">

								<div class="r-block-2">

									<a class="btn big-circle pull-right" href="contact.php">

										<div class="big-text">

											GET in touch today!

										</div>

										<div class="sm-text">

											We'll fix all your Problems!

										</div>

									</a>

								</div>
								</div>

							</div>

						</div>

					</div>

				</div>

				<div class="tooth-color-gr"></div>

			</section>

			<section class="quote-olw bg-wrapper q-h-1">

				<div class="wrapper">

					<div class="row-1">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

							<div class="section-title-box wow rollIn center  ">

								<h2>Happy Customers</h2>

								
							</div>

						</div>

					</div>

					<div class="row-1">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

							<div id="quote-olw-h1">

								<div class="quote-box">

									<quote class="quote-block-2">

										<div class="quote-wrap">

											
											<div class="text-quote">

												<p>Satpura Bio Fertilizers services are consistent, competitively priced, and their team is easy to work with.I really appreciate all of company's efforts. Anytime a vendor provides information before we have time to ask for it, I just love it.</p>

											</div>

										</div>

										<span class="ef arrow_triangle-down"></span>

									</quote>

									<div class="q-signature">

										<h4>Rakesh Jain</h4>

										<div class="q-sub"></div>

									</div>

								</div>

								<div class="quote-box">

									<quote class="quote-block-2">

										<div class="quote-wrap">

											<div class="text-quote">
<p> I have used Humix Humic Acid for the growth of plants roots., it shows tremendous and excellent result  for crop cultivation. I should suggested that people should use this golden product. It is perfect product for agriculture field and I also thanks the Satpura Bio Fertilizers for there best products.</p>

												

											</div>

										</div>

										<span class="ef arrow_triangle-down"></span>

									</quote>

									<div class="q-signature">

										<h4>Mayur Sharma</h4>

										<div class="q-sub"></div>

									</div>

								</div>

							<div class="quote-box">

									<quote class="quote-block-2">

										<div class="quote-wrap">

											

											<div class="text-quote">
<p>I have applied Bhumi Rakshak in my flower crop within 20 days i got very excellent result .I have getting regular good yield. It is wonderful I have got best results. Thanks to Satpura Bio Fertilizers pvt ltd.</p>

											</div>

										</div>

										<span class="ef arrow_triangle-down"></span>

									</quote>

									<div class="q-signature">

										<h4>Rayasil Zadu</h4>

										<div class="q-sub"></div>

									</div>

								</div>

							<!--	<div class="quote-box">

									<quote class="quote-block-2">

										<div class="quote-wrap">

											<div class="quote-photo">

												<img class="#" alt="image" src="media/76x76/image1.jpg">

											</div>

											<div class="text-quote">

												<p>Nulla euismod malesuada nibh. Donec nunc. Praesent sit amet turpis eu nisl faucibus pharetra. Fusce quis neque vel leo semp er rhoncus. Ut interdum, risus id luctus consectetuer velit neq ue ornare quam beat ornare nisi velit nec turpis. Mauris lorem. Phasellus egestas urna vel sem. Ut auctor.</p>

											</div>

										</div>

										<span class="ef arrow_triangle-down"></span>

									</quote>

									<div class="q-signature">

										<h4>Jeebon Heza</h4>

										<div class="q-sub">Home Owner, Newyork</div>

									</div>

								</div>

								<div class="quote-box">

									<quote class="quote-block-2">

										<div class="quote-wrap">

											<div class="quote-photo">

												<img class="#" alt="image" src="media/76x76/image2.jpg">

											</div>

											<div class="text-quote">

												<p>Nulla euismod malesuada nibh. Donec nunc. Praesent sit amet turpis eu nisl faucibus pharetra. Fusce quis neque vel leo semp er rhoncus. Ut interdum, risus id luctus consectetuer velit neq ue ornare quam beat ornare nisi velit nec turpis. Mauris lorem. Phasellus egestas urna vel sem. Ut auctor.</p>

											</div>

										</div>

										<span class="ef arrow_triangle-down"></span>

									</quote>

									<div class="q-signature">

										<h4>Rayasil Zadu</h4>

										<div class="q-sub">Home Owner, California</div>

									</div>

								</div>

								<div class="quote-box">

									<quote class="quote-block-2">

										<div class="quote-wrap">

											<div class="quote-photo">

												<img class="#" alt="image" src="media/76x76/image1.jpg">

											</div>

											<div class="text-quote">

												<p>Nulla euismod malesuada nibh. Donec nunc. Praesent sit amet turpis eu nisl faucibus pharetra. Fusce quis neque vel leo semp er rhoncus. Ut interdum, risus id luctus consectetuer velit neq ue ornare quam beat ornare nisi velit nec turpis. Mauris lorem. Phasellus egestas urna vel sem. Ut auctor.</p>

											</div>

										</div>

										<span class="ef arrow_triangle-down"></span>

									</quote>

									<div class="q-signature">

										<h4>Jeebon Heza</h4>

										<div class="q-sub">Home Owner, Newyork</div>

									</div>

								</div>
-->
							</div>

						</div>

					</div>

					<div class="image-folw"></div>

				</div>

			</section>

			<!--<section class="light-bg home-1-blog-post">

				<div class="wrapper">

					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

						<div class="section-title-box wow rollIn center  ">

							<h2>Blog Posts</h2>

							<span>Nam lobortis fringilla felis. Fusce vol utpat mi at urna cras quam vitae turpis</span>

						</div>

					</div>

					<div class="row">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

							<div id="owl-team">

								<div class="item wow rollIn center">

									<div class="team-img h-post-image">

										<img src="media/370x230/img-4.jpg" alt="img">

										<span class="date-post">10 <span>Apr</span></span>

										<div class="post-icon">

											<span class="ef icon_image "></span>

										</div>

									</div>

									<div class="team-info-block">

										<h4>Curabitur cursus porta lectus</h4>

										<div class="info-box">

											<ul>

												<li>

													By Admin

												</li>

												<li>

													Garden Care

												</li>

												<li>

													3 Comments

												</li>

											</ul>

										</div>

										<p>Neque arcu tincidunt neque pharetra coduct mod nibh leo non libero. Cras augue ipsum phare train

											sed.  Integ er ante nunc accumsan.</p>

									</div>

								</div>



								<div class="item wow pulse">

									<div class="team-img h-post-image">

										<img src="media/370x230/img-5.jpg" alt="img">

										<span class="date-post">10 <span>Apr</span></span>

										<div class="post-icon">

											<span class="ef icon_pencil_alt "></span>

										</div>

									</div>

									<div class="team-info-block">

										<h4>Suspendisse purus id sapien</h4>

										<div class="info-box">

											<ul>

												<li>

													By Admin

												</li>

												<li>

													Garden Care

												</li>

												<li>

													3 Comments

												</li>

											</ul>

										</div>

										<p>Neque arcu tincidunt neque pharetra coduct mod nibh leo non libero. Cras augue ipsum phare train

											sed.  Integ er ante nunc accumsan.</p>

									</div>

								</div>



								<div class="item wow bounceInRight center">

									<div class="team-img h-post-image">

										<img src="media/370x230/img-6.jpg" alt="img">

										<span class="date-post">10 <span>Apr</span></span>

										<div class="post-icon">

											<span class="ef icon_film "></span>

										</div>

									</div>

									<div class="team-info-block">

										<h4>Mauris lectus enim luctus vitae</h4>

										<div class="info-box">

											<ul>

												<li>

													By Admin

												</li>

												<li>

													Garden Care

												</li>

												<li>

													3 Comments

												</li>

											</ul>

										</div>

										<p>Neque arcu tincidunt neque pharetra coduct mod nibh leo non libero. Cras augue ipsum phare train

											sed.  Integ er ante nunc accumsan.</p>

									</div>

								</div>



								<div class="item">

									<div class="team-img h-post-image">

										<img src="media/370x230/img-4.jpg" alt="img">

										<span class="date-post">10 <span>Apr</span></span>

										<div class="post-icon">

											<span class="ef icon_image "></span>

										</div>

									</div>

									<div class="team-info-block">

										<h4>Curabitur cursus porta lectus</h4>

										<div class="info-box">

											<ul>

												<li>

													By Admin

												</li>

												<li>

													Garden Care

												</li>

												<li>

													3 Comments

												</li>

											</ul>

										</div>

										<p>Neque arcu tincidunt neque pharetra coduct mod nibh leo non libero. Cras augue ipsum phare train

											sed.  Integ er ante nunc accumsan.</p>

									</div>

								</div>



								<div class="item">

									<div class="team-img h-post-image">

										<img src="media/370x230/img-5.jpg" alt="img">

										<span class="date-post">10 <span>Apr</span></span>

										<div class="post-icon">

											<span class="ef icon_pencil_alt "></span>

										</div>

									</div>

									<div class="team-info-block">

										<h4>Suspendisse purus id sapien</h4>

										<div class="info-box">

											<ul>

												<li>

													By Admin

												</li>

												<li>

													Garden Care

												</li>

												<li>

													3 Comments

												</li>

											</ul>

										</div>

										<p>Neque arcu tincidunt neque pharetra coduct mod nibh leo non libero. Cras augue ipsum phare train

											sed.  Integ er ante nunc accumsan.</p>

									</div>

								</div>



								<div class="item">

									<div class="team-img h-post-image">

										<img src="media/370x230/img-6.jpg" alt="img">

										<span class="date-post">10 <span>Apr</span></span>

										<div class="post-icon">

											<span class="ef icon_film "></span>

										</div>

									</div>

									<div class="team-info-block">

										<h4>Mauris lectus enim luctus vitae</h4>

										<div class="info-box">

											<ul>

												<li>

													By Admin

												</li>

												<li>

													Garden Care

												</li>

												<li>

													3 Comments

												</li>

											</ul>

										</div>

										<p>Neque arcu tincidunt neque pharetra coduct mod nibh leo non libero. Cras augue ipsum phare train

											sed.  Integ er ante nunc accumsan.</p>

									</div>

								</div>



								<div class="item">

									<div class="team-img h-post-image">

										<img src="media/370x230/img-4.jpg" alt="img">

										<span class="date-post">10 <span>Apr</span></span>

										<div class="post-icon">

											<span class="ef icon_image "></span>

										</div>

									</div>

									<div class="team-info-block">

										<h4>Curabitur cursus porta lectus</h4>

										<div class="info-box">

											<ul>

												<li>

													By Admin

												</li>

												<li>

													Garden Care

												</li>

												<li>

													3 Comments

												</li>

											</ul>

										</div>

										<p>Neque arcu tincidunt neque pharetra coduct mod nibh leo non libero. Cras augue ipsum phare train

											sed.  Integ er ante nunc accumsan.</p>

									</div>

								</div>



								<div class="item">

									<div class="team-img h-post-image">

										<img src="media/370x230/img-5.jpg" alt="img">

										<span class="date-post">10 <span>Apr</span></span>

										<div class="post-icon">

											<span class="ef icon_pencil_alt "></span>

										</div>

									</div>

									<div class="team-info-block">

										<h4>Suspendisse purus id sapien</h4>

										<div class="info-box">

											<ul>

												<li>

													By Admin

												</li>

												<li>

													Garden Care

												</li>

												<li>

													3 Comments

												</li>

											</ul>

										</div>

										<p>Neque arcu tincidunt neque pharetra coduct mod nibh leo non libero. Cras augue ipsum phare train

											sed.  Integ er ante nunc accumsan.</p>

									</div>

								</div>



								<div class="item">

									<div class="team-img h-post-image">

										<img src="media/370x230/img-6.jpg" alt="img">

										<span class="date-post">10 <span>Apr</span></span>

										<div class="post-icon">

											<span class="ef icon_film "></span>

										</div>

									</div>

									<div class="team-info-block">

										<h4>Mauris lectus enim luctus vitae</h4>

										<div class="info-box">

											<ul>

												<li>

													By Admin

												</li>

												<li>

													Garden Care

												</li>

												<li>

													3 Comments

												</li>

											</ul>

										</div>

										<p>Neque arcu tincidunt neque pharetra coduct mod nibh leo non libero. Cras augue ipsum phare train

											sed.  Integ er ante nunc accumsan.</p>

									</div>

								</div>



							</div>

						</div>

					</div>

				</div>

			</section>-->

			<!--<section class="color-bg box-tools-bg percent-blocks">

				<div class="wrapper">

					<div class="row-1">

						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

							<ul class="our-info h1">

								<li class="chart" data-percent="1500">

									<span class="ef icon_like_alt"></span>

									<div class="number percent"></div>

									<div class="text">Completed Projects</div>

								</li>

								<li class="chart" data-percent="358">

									<span class="ef icon_group"></span>

									<div class="number percent"></div>

									<div class="text">Satisfied Customers</div>

								</li>

								<li class="chart" data-percent="26">

									<span class="ef icon_house"></span>

									<div class="number percent"></div>

									<div class="text">Nationwide Branches</div>

								</li>

								<li class="chart" data-percent="2641">

									<span class="ef icon_tools"></span>

									<div class="number percent"></div>

									<div class="text">Free Quotes Sent</div>

								</li>

							</ul>

						</div>

					</div>

				</div>

				<div class="tooth-color-d"></div>

			</section>-->
            

			<?php include "footer.php"; ?>