	<?php include"header.php"; ?>
            
			<div class="bg-wrapper">
				<section id="title-box" class="paralax bg-opacity-color shop">
					<div class="wrapper">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<h1>Gallery</h1>
							<span class="subtitle">The Home Of best Products</span>
						</div>
					</div>
				</section>
				<section id="breadcrumbs" class="tooth tooth-green">
					<div class="section-bg">
						<div class="wrapper">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<ul>
									<li>
										<a href="index.php">Home</a>
									</li>
									<li>
										<a href="product.php">Gallery</a>
									</li>
									
								</ul>
							</div>
						</div>
					</div>
				</section>
				<section class="two-columns">
					<div class="wrapper">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pull-right">

							

							<div class="shop-grid">
								<div class="row wow fadeInUp">
									<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
										<div class="product-box">
											<div class="product-image">
												<a href="silicon-soil-conditioner.php">
													<img src="img/rak-l.jpg" alt="product"/>
												</a>
											</div>
											<div class="product-desc-wrapper">
												<div class="product-title"><span>Silicon Soil Conditioner</span></div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 450 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
										<div class="product-box">
											<div class="product-image">
												<a href="humic-base.php">
													<img src="img/humi-l.jpg" alt="product"/>
												</a>
											</div>
											<div class="product-desc-wrapper">
												<div class="product-title"><span>Humic Base Organic Manure</span></div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs --- / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
										<div class="product-box">
											<div class="product-image">
												<a href="zyme-granules.php">
													<img src="img/zyme-l.jpg" alt="product"/>
												</a>
											</div>
											<div class="product-desc-wrapper">
												<div class="product-title"><span>Royal Zyme</span></div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs --- / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									</div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
										<div class="product-box">
											<div class="product-image">
												<a href="neemx.php">
													<img src="img/neem-l.jpg" alt="product"/>
												</a>
											</div>
											<div class="product-desc-wrapper">
												<div class="product-title"><span>Neem Cake</span></div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 300 / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									</div>
								</div>

								<div class="row wow fadeInUp">
									
									<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
										<div class="product-box">
											<div class="product-image">
												<a href="bio-active.php">
													<img src="img/active-l.jpg" alt="product"/>
												</a>
											</div>
											<div class="product-desc-wrapper">
												<div class="product-title"><span>Satpura Bio Active</span></div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs --- / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
										<div class="product-box">
											<div class="product-image">
												<a href="growth-promoter.php">
													<img src="img/premium-l.jpg" alt="product"/>
												</a>
											</div>
											<div class="product-desc-wrapper">
												<div class="product-title"><span>Growth Promoter</span></div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs --- / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									</div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
										<div class="product-box">
											<div class="product-image">
												<a href="humic-acid.php">
													<img src="img/humix-l.jpg" alt="product"/>
												</a>
											</div>
											<div class="product-desc-wrapper">
												<div class="product-title"><span>Humix Humic Acid</span></div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs --- / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									</div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
										<div class="product-box">
											<div class="product-image">
												<a href="bio-stimulant.php">
													<img src="img/amaze-l.jpg" alt="product"/>
												</a>
											</div>
											<div class="product-desc-wrapper">
												<div class="product-title"><span>Bio Stimulant</span></div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs 500 / Piece(s)</div>
														
													</div>
												</div>-->
											</div>
										</div>
									</div>
								</div>

								<div class="row wow fadeInUp">
									
									
									<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
										<div class="product-box">
											<div class="product-image">
												<a href="wetting.php">
													<img src="img/classic-l.jpg" alt="product"/>
												</a>
											</div>
											<div class="product-desc-wrapper">
												<div class="product-title"><span>Wetting</span></div>
												
												<!--<div class="row-pr">
													
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<div class="price"> Rs --- / bag</div>
														
													</div>
												</div>-->
											</div>
										</div>
									</div>
								</div>
							</div>

							<!--<div class="pagination-box">
								<ul>
									<li class="arrow-pagin">
									<a href="#">
									<span class="ef arrow_left"></span>
									</a>
									</li>
									<li class="active">
										<span class="number-pag">1</span>
									</li>
									<li>
										<a href="#">
											<span class="number-pag">2</span>
										</a>
									</li>
									<li>
										<a href="#">
											<span class="number-pag">3</span>
										</a>
									</li>
									<li class="arrow-pagin">
										<a href="#">
											<span class="ef arrow_right"></span>
										</a>
									</li>
								</ul>
							</div>-->

						</div>

						
					</div>
				</section>
				
                
					<?php include"footer.php"; ?>